from __future__ import print_function
import sys
import keras
from keras.models import Sequential
import tensorflow as tf
import random


import pickle
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

from read_data import read_data
import os   


def train(model,data,sample_fraction):
    print("-- RUNNING TRAINING --", flush=True)

    batch_size = 32
    epochs = 3

    x_train, y_train = read_data(data,sample_fraction=sample_fraction)

    model.fit(x_train, y_train, batch_size=batch_size, epochs=epochs, verbose=True)

    print("-- TRAINING COMPLETED --", flush=True)
    return model

if __name__ == '__main__':

    from fedn.utils.kerassequential import KerasSequentialHelper
    helper = KerasSequentialHelper()
    model = helper.load_model(sys.argv[1])
    model = train(model, '../data/train.csv', sample_fraction=0.25)
    helper.save_model(model, sys.argv[2])



