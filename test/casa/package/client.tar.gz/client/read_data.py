import numpy
import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import normalize, StandardScaler, LabelEncoder
import keras
import sys
import numpy as np
import scipy
import scipy.io
# import sys
# sys.setrecursionlimit(10000)
from keras.utils import to_categorical

def read_data(filename, sample_fraction=1.0):
    """ Helper function to read and preprocess data for training with Keras. """

    """ Read the prepared and normlized data, where the features number is 36 and the output is 10 classes """

    pkd = np.array(pd.read_csv(filename))
    X = pkd[:, 1:37]
    y = pkd[:, 37:]
    foo, X, bar, y = train_test_split(X, y, test_size=sample_fraction)
    """reshaped the input data for LSTM model """
    X = X.reshape(X.shape[0], 1, X.shape[1])

    return X, y


