#!/bin/bash
fedn run fedavg -d discovery -p 8080 -t e9a3cb4c5eaff546eec33ff68a7fbe232b68a192 -h combiner -i 12080 -n combiner