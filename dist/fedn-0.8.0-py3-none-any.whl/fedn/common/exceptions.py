class ModelError(BaseException):
    pass


class InvalidClientConfig(BaseException):
    pass
