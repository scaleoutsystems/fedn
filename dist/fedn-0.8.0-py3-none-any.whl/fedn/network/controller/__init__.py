""" The controller package is responsible for orchestrating the federated learning process. It's acts as a gRPC client and sends round config tasks 
to the :class:`fedn.network.combiner.Combiner`. """
# flake8: noqa
