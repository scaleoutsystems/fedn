""" The statestore package is responsible for storing various states of the federated network. Such as announced combiners and assigned clients. It also stores metadata about
models, rounds, sessions, compute packages and model validations. """
# flake8: noqa
