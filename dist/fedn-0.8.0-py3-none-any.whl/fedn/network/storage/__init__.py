"""Module handling both transient and persistent storage of model objects and system state."""
