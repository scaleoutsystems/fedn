"""Module handling storing state in the backend database (currently MongoDB)."""
