""" API module for the FEDn network. Includes a REST-API server to interact with the controller
and statestore."""
# flake8: noqa
