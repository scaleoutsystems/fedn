""" The aggregator package is responsible for aggregating models from multiple clients. It's called both in :class:`fedn.network.combiner.Combiner` and :class:`fedn.network.controller.Controller` 
to aggregate models from clients. """
# flake8: noqa
